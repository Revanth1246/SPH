package Selenium;

import org.openqa.selenium.By;

import java.io.File;
import java.io.IOException;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecuteResultHandler;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.*;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import io.appium.java_client.MobileElement;
import io.appium.java_client.*;
import io.appium.java_client.android.AndroidDriver;

public class Android_Shared_Library {
	
	public static AndroidDriver driver;
	public static  ExtentReports extent;
	public static  ExtentTest test;
	 Process p;
	 String nodePath = "C:\\Program Files\\nodejs\\node.exe";
	 // Set path of your appium.js file.
	 String appiumJSPath = "C:\\Users\\RevanthKumar\\AppData\\Local\\Programs\\Appium\\resources\\app\\node_modules\\appium\\build\\lib\\appium.js";
	 String cmd = nodePath + " " + appiumJSPath;
	 //WebDriver driver;
	public static void EnterKeys(By by,String text) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(by).clear();
		Thread.sleep(2000);
		driver.findElement(by).sendKeys(text);
	}
	public static void Click(By by)
	{
		
		driver.findElement(by).click();
	}
	public static void scroll(By by)
	{
		MobileElement element = (MobileElement) (driver.findElement(by));
		Actions actions = new Actions(driver);
		actions.moveToElement(element);
		actions.perform();
	}
	public static void driver_wait(By by) throws Exception
	{
		MobileElement element = (MobileElement) (driver.findElement(by));
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, 100);
		element = (MobileElement)wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}
	public static void And_driver_wait(By by) throws Exception
	{
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, 100);
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}
	public static String GetText(By by)
	{
		String  textvalue;
		textvalue=driver.findElement(by).getText();
		return textvalue;
	}
	 public void appiumStart() throws IOException, InterruptedException {
		  // Execute command string to start appium server.
		  p = Runtime.getRuntime().exec(cmd);
		  // Provide wait time of 10 mins to start appium server properly.
		  // If face any error(Could not start a new session...) then Increase
		  // this time to 15 or 20 mins.
		  Thread.sleep(10000);
		  if (p != null) {
		   System.out.println("Appium server Is started now.");
		  }
		 }

		 // This method Is responsible for stopping appium server.
		 public void appiumStop() throws IOException {
		  if (p != null) {
		   p.destroy();
		  }
		  System.out.println("Appium server Is stopped now.");
		 }

	
}
