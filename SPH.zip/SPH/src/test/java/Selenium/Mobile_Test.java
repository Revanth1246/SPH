package Selenium;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.service.local.AppiumDriverLocalService;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import com.relevantcodes.extentreports.ExtentReports;
import cucumber.api.java.en.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
public class Mobile_Test extends Android_Shared_Library{
	Android_Shared_Library SF=new Android_Shared_Library();
	public static AndroidDriver<MobileElement> driver=null;
    public static AppiumDriverLocalService service=null;
	@Given("^User launches the StraitsTimes App$")
	public void user_launches_the_StraitsTimes_App() throws Throwable {
		SF.appiumStop();
	   // SF.start();
		
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("appPackage", "com.buuuk.st");
		capabilities.setCapability("VERSION", "5.0.2"); 
		capabilities.setCapability("deviceName","SM-A7000");
		capabilities.setCapability("platformName","Android");
		capabilities.setCapability("appActivity", "com.sph.straitstimes.views.activities.SplashActivity");
		  try {
				driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),capabilities);
			} catch (MalformedURLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}	  
		   test = extent.startTest("SPH_Mobile","SPH_Mobile"); 	
       
	}

	@Given("^then user taps on drawer Menu$")
	public void then_user_taps_on_drawer_Menu() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver_wait(By.id("com.buuuk.st:id/btn_tnc_ok"));
		  MobileElement el1 = (MobileElement) driver.findElementById("com.buuuk.st:id/btn_tnc_ok");
		  el1.click();	  
		    driver_wait(By.id("com.buuuk.st:id/welcome"));		    
		   MobileElement elements=(MobileElement)driver.findElements(By.id("com.buuuk.st:id/viewPagerCountDots"));
		   List<MobileElement> li = driver.findElements(By.id("com.buuuk.st:id/viewPagerCountDots"));
		   for(int i=0;i< li.size();i++)
		   {
			   li.get(i).click();
			   Thread.sleep(5000);
		   }       
		   
		  MobileElement el2 = (MobileElement) driver.findElementById("com.buuuk.st:id/get_started");
		  el2.click();
		  driver_wait(By.xpath("//android.widget.ImageButton[@content-desc=\"Navigate up\"]"));
		  MobileElement el3 = (MobileElement) driver.findElementByAccessibilityId("Navigate up");
		  el3.click();
	}

	@Given("^user Login with	username and password successfully$")
	public void user_Login_with_username_and_password_successfully() throws Throwable {
		  driver_wait(By.id("com.buuuk.st:id/tv_title"));
		  test.log(LogStatus.PASS,"App Launched successfully");
		  MobileElement el4 = (MobileElement) driver.findElementById("com.buuuk.st:id/tv_title");
		  el4.click();
		  driver_wait(By.id("com.buuuk.st:id/et_ldap_login_username"));
		  MobileElement el5 = (MobileElement) driver.findElementById("com.buuuk.st:id/et_ldap_login_username");
		  el5.sendKeys("digitaltest9");
		  MobileElement el6 = (MobileElement) driver.findElementById("com.buuuk.st:id/et_ldap_login_password");
		  el6.click();
		  el6.sendKeys("Sphdigital1");
		  el6.click();
		  MobileElement el7 = (MobileElement) driver.findElementById("com.buuuk.st:id/btn_ldap_login_continue");
		  el7.click();
		  driver_wait(By.id("com.buuuk.st:id/article_title"));
	}

	@Then("^article should be is displayed with videos$")
	public void article_should_be_is_displayed_with_videos() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 MobileElement el8 = (MobileElement) driver.findElementById("com.buuuk.st:id/article_title");
		  el8.click();		  
		  MobileElement el9 = (MobileElement) driver.findElementById("com.buuuk.st:id/article_image");
		  boolean image_displayed=el9.isDisplayed();
		  System.out.println(image_displayed);
	}

}
