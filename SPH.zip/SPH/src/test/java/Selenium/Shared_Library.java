package Selenium;

import org.openqa.selenium.By;

import java.io.File;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.*;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import io.appium.java_client.android.AndroidDriver;

public class Shared_Library {
	public static WebDriver driver;
	public static AndroidDriver And_driver;
	public static  ExtentReports extent;
	public static  ExtentTest test;
	public static void EnterKeys(By by,String text) throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(by).clear();
		Thread.sleep(2000);
		driver.findElement(by).sendKeys(text);
	}
	public static void Click(By by)
	{
		
		driver.findElement(by).click();
	}
	public static void scroll(By by)
	{
		WebElement element = driver.findElement(by);
		Actions actions = new Actions(driver);
		actions.moveToElement(element);
		actions.perform();
	}
	public static void driver_wait(By by) throws Exception
	{
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(driver, 100);
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}
	public static void And_driver_wait(By by) throws Exception
	{
		Thread.sleep(2000);
		WebDriverWait wait = new WebDriverWait(And_driver, 100);
		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
	}
	public static String GetText(By by)
	{
		String  textvalue;
		textvalue=driver.findElement(by).getText();
		return textvalue;
	}
	 
	
}
