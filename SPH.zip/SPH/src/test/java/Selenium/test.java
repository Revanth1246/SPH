package Selenium;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import com.relevantcodes.extentreports.ExtentReports;
import cucumber.api.java.en.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.awt.Dimension;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.relevantcodes.extentreports.ExtentReports;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class test extends Shared_Library{
	
	
	
	@Given("^user is  on homepage$")
	public void user_is_on_homepage() throws Throwable {
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		  LocalDateTime now = LocalDateTime.now();
        String value=dtf.format(now).toString();
		extent = new ExtentReports("./report/result_"+value+".html",true);
        driver.get("http://straitstimes.com");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        test = extent.startTest("SPH","SPH");   
        System.out.println("Waiting done is ");
        // IFrame handling for advertisement
        try {
        	WebElement element=driver.findElement(By.xpath("/html/body/div[10]/iframe"));
        	 driver.switchTo().frame(element);
             System.out.println("Switched done is ");
             Click(By.id("celtra-object-236"));
             driver.switchTo().defaultContent();
        }catch(Exception e){
        	//
          	WebElement element=driver.findElement(By.xpath("//*[contains(@id,'_expand_iframe_')]"));
          	driver.switchTo().frame(element);
            Click(By.id("close-button"));
            driver.switchTo().defaultContent();
        	
        }        
        driver_wait(By.xpath("//*[text()='Login']"));
	}    
    
    @When("^user navigates to Login Page$")
    public void user_navigates_to_Login_Page() throws Throwable {
    	 	
        Click(By.xpath("//*[text()='Login']"));
        driver_wait(By.name("j_username"));
        extent.flush();
    }
    
    
    @When("^user login with username and Password$")
    public void user_login_with_username_and_Password() throws Throwable {
    	EnterKeys(By.name("j_username"),"digitaltest9");
    	EnterKeys(By.name("j_password"),"Sphdigital1");
    	Click(By.xpath("//*[@type='submit']"));
    	driver_wait(By.name("login-user-name"));
    	String login_name=GetText(By.name("login-user-name"));
    	System.out.println("Username is "+login_name);
    	extent.flush();
    	if(login_name.toLowerCase().equals("digitaltest9"))
    	{
    		test.log(LogStatus.PASS,"Login with username "+login_name+" is successful");
    	}
    	else
    	{
    		test.log(LogStatus.FAIL,"Login with username "+login_name+" is not successful with userid-digitaltest9");
    	}
      
    	
    
    }

    @When("^Click on Main article$")
    public void click_on_Main_article() throws Throwable {
    	Boolean Main_article_displayed=driver.findElement(By.xpath("//*[@data-vr-zone='Top Stories 0']")).isDisplayed();
    	System.out.println("displayed is "+Main_article_displayed);
    	if(Main_article_displayed==true)
    	{
    		test.log(LogStatus.PASS,"Main article is displayed successfully");
    	}
    	else
    	{
    		test.log(LogStatus.FAIL,"Main article is not displayed");
    	}
    	try {    	
    	String Article_image=driver.findElement(By.xpath("//*[@data-vr-zone='Top Stories 0']/div[1]/div[1]/div/ul/li/div/div/div")).getAttribute("class");
    	System.out.println("text is "+Article_image);
    	if(Article_image!=null)
    	{
    		test.log(LogStatus.PASS,"Main article is displayed with image successfully");
    	}
    	else
    	{
    		test.log(LogStatus.FAIL,"Main article is not displayed with image");
    	}
    	}catch(Exception e) {}
    	Thread.sleep(2000);
        // Write code here that turns the phrase above into concrete actions
    	scroll(By.xpath("//*[@data-vr-zone='Top Stories 0']"));
    	Thread.sleep(2000);
    	Click(By.xpath("//*[@data-vr-zone='Top Stories 0']"));
    	driver_wait(By.xpath("//*[@itemprop='headline']"));
    	System.out.println("Get texyt value is is "+ GetText(By.xpath("//*[@itemprop='headline']"))); 	
		
		extent.flush();
    }
    @Then("^success message is displayed$")
    public void success_message_is_displayed() throws Throwable {
    	List<WebElement> Image_list = driver.findElements(By.xpath("//picture[@class='img-responsive']/img"));
    	String Article_title=Image_list.get(0).getAttribute("src");
    	System.out.println("Get texyt value is is "+ Article_title);
    	if(Article_title!=null)
    	{
    		test.log(LogStatus.PASS,"Main article is displayed with image");
    	}
    	else
    	{
    		test.log(LogStatus.FAIL,"Main article is not displayed with image");
    	}
		extent.endTest(test);
		extent.flush();
        driver.quit();  
    }   

}
