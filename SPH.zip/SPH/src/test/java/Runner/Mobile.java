package Runner;

import org.junit.runner.RunWith;
import org.testng.annotations.AfterClass;

import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
dryRun=false,
features = "C:\\Users\\RevanthKumar\\eclipse-workspace\\SPH\\src\\test\\java\\Features"

,glue={"Selenium"},

plugin = { "com.cucumber.listener.ExtentCucumberFormatter:report/result.html"}
		
		, monochrome = true
)
public class Mobile extends AbstractTestNGCucumberTests {

}
